xpkg
====
A package manager for Mac OS X

Open src/xpkg as a workspace in XCode and begin editing...

Notes
====
It dosen't really work right now...

Depends
====
Xcode Command Line Tools
